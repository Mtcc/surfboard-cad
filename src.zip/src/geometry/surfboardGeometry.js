/**
 * Surfboard Geometry Engine v3
 *
 * Coordinate system (Three.js Y-up, board lying flat):
 *   X = length axis  (nose = -L/2, tail = +L/2)
 *   Y = height axis  (bottom at rocker height, deck = rocker + thickness)
 *   Z = width axis   (centerline = 0, right rail = +Z, left = -Z)
 *
 * Key measurement conventions:
 *   noseWidthIn     = board width measured at 12" from nose tip
 *   widePointIn     = distance from nose to the mathematically widest point (inches)
 *   widePointWidthIn= actual maximum width of the board
 *   tailWidthIn     = board width measured at 12" from tail tip
 *
 * For fish boards: widePointIn ≈ 29-33" (near center); nose ~14" on a 21" wide fish.
 * For shortboards: widePointIn ≈ 37-44", nose is distinctly narrower.
 */

import * as THREE from 'three';

export function inchesToMeters(i) { return i * 0.0254; }

// ---------------------------------------------------------------------------
// Catmull-Rom interpolation (4-point, t ∈ [0,1])
// ---------------------------------------------------------------------------
function catmullRom(t, p0, p1, p2, p3) {
  const t2 = t * t, t3 = t2 * t;
  return 0.5 * (
    2 * p1 +
    (-p0 + p2) * t +
    (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 +
    (-p0 + 3 * p1 - 3 * p2 + p3) * t3
  );
}

/**
 * Evaluate a Catmull-Rom spline at position x.
 * ctrlPts: Array of {x, v} sorted ascending by x.
 * The spline passes exactly through every control point.
 */
function evalSpline(ctrlPts, x) {
  const n = ctrlPts.length;
  if (n === 0) return 0;
  if (n === 1) return ctrlPts[0].v;
  if (x <= ctrlPts[0].x) return ctrlPts[0].v;
  if (x >= ctrlPts[n - 1].x) return ctrlPts[n - 1].v;

  let seg = n - 2;
  for (let i = 0; i < n - 1; i++) {
    if (x < ctrlPts[i + 1].x) { seg = i; break; }
  }

  const x0 = ctrlPts[seg].x,     x1 = ctrlPts[seg + 1].x;
  const localT = x1 === x0 ? 0 : (x - x0) / (x1 - x0);

  const p0 = ctrlPts[Math.max(0, seg - 1)].v;
  const p1 = ctrlPts[seg].v;
  const p2 = ctrlPts[seg + 1].v;
  const p3 = ctrlPts[Math.min(n - 1, seg + 2)].v;

  return catmullRom(localT, p0, p1, p2, p3);
}

// Single cubic Bezier (for rocker curve shape)
function bez(t, p0, p1, p2, p3) {
  const u = 1 - t;
  return u*u*u*p0 + 3*u*u*t*p1 + 3*u*t*t*p2 + t*t*t*p3;
}

// ---------------------------------------------------------------------------
// REFERENCE OUTLINES
// Normalized plan-view half-width for each board type.
//   t = position along board length  (0 = nose tip, 1 = tail tip)
//   w = half-width fraction of max   (0 = centerline, 1 = widest point)
//
// Anchor values at the industry standard 12" measurement stations are
// calibrated to real production board specs (see templates.js comments).
// generateOutline() applies a small correction to hit the exact
// noseWidthIn / tailWidthIn params the user has set.
// ---------------------------------------------------------------------------
const REFERENCE_OUTLINES = {
  // ── Fish ──────────────────────────────────────────────────────────────
  // Hallmarks: very blunt wide nose, parallel rails, wide swallow tail.
  // Nose ref (12"): 14.0/21.0 = 0.67  |  Tail ref (54"): 15.5/21.0 = 0.74
  // Inspired by Christenson / Skip Frye / Steve Lis fish shapes.
  fish: [
    { t: 0.00, w: 0.52 },  // wide blunt nose — almost flat across, characteristic fish
    { t: 0.06, w: 0.72 },  // rapid bloom
    { t: 0.12, w: 0.86 },
    { t: 0.18, w: 0.93 },  // ← 12" nose ref  ✓
    { t: 0.26, w: 0.98 },
    { t: 0.33, w: 1.00 },  // wide point slightly forward of centre
    { t: 0.48, w: 1.00 },  // parallel rail section
    { t: 0.58, w: 0.98 },
    { t: 0.65, w: 0.94 },
    { t: 0.72, w: 0.89 },
    { t: 0.79, w: 0.83 },  // ← 12" tail ref  ✓
    { t: 0.86, w: 0.77 },
    { t: 0.92, w: 0.71 },
    { t: 0.96, w: 0.66 },
    { t: 1.00, w: 0.62 },  // wide fish/swallow tail base
  ],
  // ── Performance Shortboard ────────────────────────────────────────────
  // Narrow nose, wide point behind centre, tucked rails.
  // Nose ref: 10.75/19.5 = 0.55  |  Tail ref: 14.75/19.5 = 0.76
  performanceShortboard: [
    { t: 0.00, w: 0.03 },  // narrow nose tip
    { t: 0.08, w: 0.22 },
    { t: 0.16, w: 0.55 },  // ← 12" nose ref  ✓
    { t: 0.26, w: 0.74 },
    { t: 0.38, w: 0.90 },
    { t: 0.47, w: 0.97 },
    { t: 0.54, w: 1.00 },  // wide point
    { t: 0.64, w: 0.92 },
    { t: 0.74, w: 0.82 },
    { t: 0.84, w: 0.76 },  // ← 12" tail ref  ✓
    { t: 0.91, w: 0.67 },
    { t: 0.96, w: 0.59 },
    { t: 1.00, w: 0.54 },  // squash tail base
  ],
  // ── Groveler ──────────────────────────────────────────────────────────
  // Wider and fuller than a shortboard. Wide point near or just forward of centre.
  // Nose ref: 11.5/20.75 = 0.55  |  Tail ref: 15.25/20.75 = 0.74
  groveler: [
    { t: 0.00, w: 0.07 },
    { t: 0.09, w: 0.30 },
    { t: 0.18, w: 0.55 },  // ← 12" nose ref  ✓
    { t: 0.26, w: 0.76 },
    { t: 0.34, w: 0.92 },
    { t: 0.42, w: 0.99 },
    { t: 0.47, w: 1.00 },  // wide point (44% of length)
    { t: 0.58, w: 0.93 },
    { t: 0.68, w: 0.84 },
    { t: 0.76, w: 0.78 },
    { t: 0.82, w: 0.74 },  // ← 12" tail ref  ✓
    { t: 0.90, w: 0.65 },
    { t: 0.95, w: 0.58 },
    { t: 1.00, w: 0.53 },  // squash tail base
  ],
  // ── Mid-Length ────────────────────────────────────────────────────────
  // Egg / funboard. Symmetric, wide point at centre.
  // Nose ref: 14.0/21.5 = 0.65  |  Tail ref: 15.5/21.5 = 0.72
  midLength: [
    { t: 0.00, w: 0.10 },
    { t: 0.07, w: 0.38 },
    { t: 0.14, w: 0.65 },  // ← 12" nose ref  ✓
    { t: 0.25, w: 0.84 },
    { t: 0.37, w: 0.95 },
    { t: 0.50, w: 1.00 },  // wide point (centre — symmetric)
    { t: 0.63, w: 0.95 },
    { t: 0.74, w: 0.84 },
    { t: 0.82, w: 0.76 },
    { t: 0.86, w: 0.72 },  // ← 12" tail ref  ✓
    { t: 0.92, w: 0.58 },
    { t: 0.96, w: 0.40 },
    { t: 1.00, w: 0.18 },  // round tail narrows significantly
  ],
  // ── Longboard ─────────────────────────────────────────────────────────
  // Very wide round nose (noserider), parallel rails, wide point slightly forward.
  // Nose ref: 17.5/22.75 = 0.77  |  Tail ref: 15.0/22.75 = 0.66
  longboard: [
    { t: 0.00, w: 0.18 },  // wide rounded nose tip (~4" on a 22.75" board)
    { t: 0.06, w: 0.52 },  // rapid bloom — noseriders open up fast
    { t: 0.11, w: 0.77 },  // ← 12" nose ref  ✓
    { t: 0.22, w: 0.90 },
    { t: 0.33, w: 0.97 },
    { t: 0.44, w: 1.00 },  // wide point starts
    { t: 0.54, w: 1.00 },  // parallel rail section ends
    { t: 0.64, w: 0.97 },
    { t: 0.73, w: 0.90 },
    { t: 0.82, w: 0.80 },
    { t: 0.89, w: 0.66 },  // ← 12" tail ref  ✓
    { t: 0.94, w: 0.52 },
    { t: 0.97, w: 0.38 },
    { t: 1.00, w: 0.24 },  // square tail (relatively wide)
  ],
  // ── Gun ───────────────────────────────────────────────────────────────
  // Narrow pin nose, wide point well behind centre, pin tail.
  // Nose ref: 11.75/19.0 = 0.62  |  Tail ref: 12.5/19.0 = 0.66
  gun: [
    { t: 0.00, w: 0.01 },  // needle nose
    { t: 0.05, w: 0.20 },
    { t: 0.10, w: 0.46 },
    { t: 0.13, w: 0.62 },  // ← 12" nose ref  ✓
    { t: 0.24, w: 0.78 },
    { t: 0.38, w: 0.91 },
    { t: 0.50, w: 0.97 },
    { t: 0.60, w: 1.00 },  // wide point (60% behind nose)
    { t: 0.70, w: 0.89 },
    { t: 0.78, w: 0.78 },
    { t: 0.84, w: 0.70 },
    { t: 0.87, w: 0.66 },  // ← 12" tail ref  ✓
    { t: 0.92, w: 0.46 },
    { t: 0.96, w: 0.22 },
    { t: 1.00, w: 0.02 },  // pin tail
  ],
};

// Linear interpolation through a reference outline array
function interpRefOutline(ref, t) {
  if (t <= ref[0].t) return ref[0].w;
  if (t >= ref[ref.length - 1].t) return ref[ref.length - 1].w;
  for (let i = 0; i < ref.length - 1; i++) {
    if (t <= ref[i + 1].t) {
      const s = (t - ref[i].t) / (ref[i + 1].t - ref[i].t);
      return ref[i].w + s * (ref[i + 1].w - ref[i].w);
    }
  }
  return ref[ref.length - 1].w;
}

// ---------------------------------------------------------------------------
// OUTLINE
// Generates the plan-view half-width at each x station along the board.
//
// Strategy: look up the normalized reference outline for the board type, then
// stretch the t-axis to place the wide point at the user's widePointIn value.
// A small correction blends the 12" nose/tail stations to match the actual
// noseWidthIn and tailWidthIn params.
// ---------------------------------------------------------------------------
export function generateOutline(params) {
  const {
    lengthIn: L,
    noseWidthIn,
    widePointIn,
    widePointWidthIn,
    tailWidthIn,
    boardType = 'performanceShortboard',
  } = params;

  const halfNose = noseWidthIn / 2;
  const halfWide = widePointWidthIn / 2;
  const halfTail = tailWidthIn / 2;

  // Look up this board type's reference outline
  const ref = REFERENCE_OUTLINES[boardType] ?? REFERENCE_OUTLINES.performanceShortboard;

  // Find where the reference curve first reaches its maximum (refWpT)
  const maxW  = Math.max(...ref.map(p => p.w));
  const refWpT = ref.find(p => p.w >= maxW * 0.9999)?.t ?? 0.5;

  // Actual wide-point position as a fraction of board length
  const actualWpT = Math.max(0.05, Math.min(0.95, widePointIn / L));

  // Interpolate reference curve with t-axis stretched so the wide point
  // lands at actualWpT (preserves the full board-type shape character).
  function interpAtT(t) {
    let refT;
    if (refWpT > 0 && refWpT < 1) {
      refT = t <= actualWpT
        ? (t / actualWpT) * refWpT
        : refWpT + ((t - actualWpT) / (1 - actualWpT)) * (1 - refWpT);
    } else {
      refT = t;
    }
    return interpRefOutline(ref, Math.max(0, Math.min(1, refT)));
  }

  // Compute how much the reference curve deviates from the user's params
  // at the standard 12" measurement stations; blend the correction smoothly.
  const refAtNose = interpAtT(12 / L);
  const refAtTail = interpAtT((L - 12) / L);
  const noseRatio = halfWide > 0 ? halfNose / halfWide : 0.5;
  const tailRatio = halfWide > 0 ? halfTail / halfWide : 0.5;
  const noseScale = refAtNose > 0.01 ? noseRatio / refAtNose : 1;
  const tailScale = refAtTail > 0.01 ? tailRatio / refAtTail : 1;

  // Sample at high resolution — 200 stations
  const SAMPLES = 200;
  const pts = [];
  for (let i = 0; i <= SAMPLES; i++) {
    const x = (i / SAMPLES) * L;
    const t = x / L;
    let w = interpAtT(t);

    // Smooth correction: linearly blend scale factor from 1.0 at the wide
    // point to noseScale/tailScale at the respective ends.
    if (t < actualWpT) {
      const blend = actualWpT > 0 ? 1 - t / actualWpT : 0;
      w *= 1 + (noseScale - 1) * blend;
    } else {
      const blend = actualWpT < 1 ? (t - actualWpT) / (1 - actualWpT) : 0;
      w *= 1 + (tailScale - 1) * blend;
    }

    pts.push({ x, halfWidth: Math.max(0, Math.min(halfWide, w * halfWide)) });
  }

  // ── 5-point weighted smoothing, 3 passes ──────────────────────────────────
  const W5 = [0.1, 0.2, 0.4, 0.2, 0.1];
  for (let pass = 0; pass < 3; pass++) {
    for (let i = 3; i < pts.length - 3; i++) {
      pts[i].halfWidth =
        pts[i - 2].halfWidth * W5[0] +
        pts[i - 1].halfWidth * W5[1] +
        pts[i    ].halfWidth * W5[2] +
        pts[i + 1].halfWidth * W5[3] +
        pts[i + 2].halfWidth * W5[4];
    }
  }

  // ── Monotone enforcement ──────────────────────────────────────────────────
  // Real rails have exactly one peak. Clamp out any secondary local maxima.
  const wpIdx = pts.reduce((best, pt, i) =>
    pt.halfWidth > pts[best].halfWidth ? i : best, 0);
  for (let i = 1; i <= wpIdx; i++)
    if (pts[i].halfWidth < pts[i - 1].halfWidth) pts[i].halfWidth = pts[i - 1].halfWidth;
  for (let i = pts.length - 2; i >= wpIdx; i--)
    if (pts[i].halfWidth < pts[i + 1].halfWidth) pts[i].halfWidth = pts[i + 1].halfWidth;

  return pts;
}

// ---------------------------------------------------------------------------
// ROCKER
// Height of board bottom above the "rocker flat" reference at each x.
// Measured as a rise from the flat center section toward the tips.
// ---------------------------------------------------------------------------
export function generateRocker(params) {
  const { lengthIn: L, noseRockerIn, tailRockerIn, entryRocker, exitRocker } = params;

  // Entry curve: how early nose rocker "kicks in" (low K = gradual, high K = early)
  const entryK = { flat: 0.06, moderate: 0.16, aggressive: 0.38 }[entryRocker] ?? 0.14;
  const exitK  = { flat: 0.06, moderate: 0.13, aggressive: 0.28 }[exitRocker]  ?? 0.11;

  const SAMPLES = 200;
  const pts = [];
  for (let i = 0; i <= SAMPLES; i++) {
    const t = i / SAMPLES;
    let z;
    if (t <= 0.5) {
      const s = 1 - t / 0.5; // 1 at nose, 0 at center
      z = bez(s, 0, entryK * noseRockerIn, noseRockerIn * 0.65, noseRockerIn);
    } else {
      const s = (t - 0.5) / 0.5; // 0 at center, 1 at tail
      z = bez(s, 0, exitK * tailRockerIn, tailRockerIn * 0.62, tailRockerIn);
    }
    pts.push({ x: t * L, z: Math.max(0, z) });
  }
  return pts;
}

// ---------------------------------------------------------------------------
// THICKNESS DISTRIBUTION (foil)
// ---------------------------------------------------------------------------
export function generateThickness(params) {
  const { lengthIn: L, noseThicknessIn, centerThicknessIn, tailThicknessIn, widePointIn } = params;

  // Use centre-of-board thickness at the wide point
  // Add a secondary peak slightly forward of widePointIn for foil accuracy
  const spine = [
    { x: 0,           v: 0.04              },
    { x: 12,          v: noseThicknessIn   },
    { x: widePointIn, v: centerThicknessIn },
    { x: L - 12,      v: tailThicknessIn   },
    { x: L,           v: 0.06              },
  ];

  const SAMPLES = 200;
  const pts = [];
  for (let i = 0; i <= SAMPLES; i++) {
    const x     = (i / SAMPLES) * L;
    const thick = Math.max(0.04, evalSpline(spine, x));
    pts.push({ x, thickness: thick });
  }
  return pts;
}

// ---------------------------------------------------------------------------
// CROSS-SECTION PROFILE
//
// Returns N+1 points tracing from bottom-center → rail → deck-center
// on the right (positive-Z) side. Mirror for left side.
//
// Each point: { y = width offset from center, z = height above bottom }
//
// Rail types change:
//   apexFrac: how high up the rail apex sits (fraction of thickness)
//   flatR:    how much of the width is flat bottom (fraction)
//   botC/topC: curvature of lower/upper rail
// ---------------------------------------------------------------------------
function crossSection(halfWidth, thickness, railType, deckDome, N = 32) {
  if (halfWidth < 0.001 || thickness < 0.002) {
    return Array.from({ length: N + 1 }, () => ({ y: 0, z: 0 }));
  }

  const domeH = halfWidth * (
    { flat: 0, low: 0.08, medium: 0.17, high: 0.28 }[deckDome] ?? 0.15
  );

  const cfg = {
    soft:    { apexFrac: 0.58, flatR: 0.66, botC: 0.08, topC: 0.82 },
    '50/50': { apexFrac: 0.50, flatR: 0.68, botC: 0.10, topC: 0.76 },
    down:    { apexFrac: 0.42, flatR: 0.70, botC: 0.18, topC: 0.66 },
    pinched: { apexFrac: 0.34, flatR: 0.72, botC: 0.28, topC: 0.56 },
    tucked:  { apexFrac: 0.28, flatR: 0.74, botC: 0.36, topC: 0.50 },
  }[railType] ?? { apexFrac: 0.50, flatR: 0.68, botC: 0.10, topC: 0.76 };

  const apexH = thickness * cfg.apexFrac;
  const flatY = halfWidth * cfg.flatR;

  // 7-point profile skeleton — each point is on the actual profile curve
  // Path: bottom-center → flat bottom → lower rail curve → rail apex →
  //       upper rail → deck shoulder → deck center (with dome)
  const ctrl = [
    { y: 0,                    z: 0           },  // 0: bottom center
    { y: flatY,                z: 0           },  // 1: end of flat bottom
    { y: halfWidth * 0.88,     z: apexH * cfg.botC }, // 2: lower rail blend
    { y: halfWidth,            z: apexH       },  // 3: RAIL APEX (outermost)
    { y: halfWidth * cfg.topC, z: thickness * 0.83 }, // 4: upper rail
    { y: halfWidth * 0.24,     z: thickness   },  // 5: deck shoulder
    { y: 0,                    z: thickness + domeH }, // 6: deck center
  ];

  // Sample with Catmull-Rom through the skeleton (index-parameterized)
  const ys = ctrl.map((p, i) => ({ x: i, v: p.y }));
  const zs = ctrl.map((p, i) => ({ x: i, v: p.z }));
  const maxI = ctrl.length - 1;

  const pts = [];
  for (let i = 0; i <= N; i++) {
    const t = (i / N) * maxI;
    pts.push({
      y: Math.max(0, evalSpline(ys, t)),
      z: evalSpline(zs, t),
    });
  }
  return pts;
}

// ---------------------------------------------------------------------------
// VOLUME  (cubic inches → liters)
//
// Standard industry formula:
//   Volume ≈ (Length × Width × Thickness × shapeFactor) / 61.024
//
// shapeFactor varies by outline fullness: 0.58 (guns) to 0.68 (fish)
// We compute it dynamically by integrating the actual outline.
// ---------------------------------------------------------------------------
export function calculateVolume(params) {
  const outline = generateOutline(params);
  const thick   = generateThickness(params);
  const n = outline.length;

  // Compute average section fill factor (how full the cross-section is)
  // Standard surfboard cross-sections are ~72-78% of the bounding rectangle
  // 0.80: cross-section is ~80% of bounding rectangle (accounts for curved rails,
  // deck dome). Outline taper is already captured by the integration itself.
  const shapeFactor = 0.80;

  let vol = 0;
  for (let i = 0; i < n - 1; i++) {
    const dx = outline[i + 1].x - outline[i].x;
    vol += (outline[i].halfWidth * 2) * thick[i].thickness * dx;
  }
  // shapeFactor accounts for cross-section fill (rails curve the outline inward).
  // The outline taper is already captured by the integration, so this only
  // corrects for the elliptical/lenticular cross-section vs bounding rectangle.
  return (vol * shapeFactor) / 61.024;
}

// ---------------------------------------------------------------------------
// MAIN GEOMETRY BUILDER
// Generates Three.js BufferGeometry from surfboard parameters.
//
// Nose and tail closures use prepended/appended outline stations that sine-ramp
// to near-zero halfWidth, so the ring loop produces smooth domes without
// separate cap code. Swallow tail gets ring-center deformation after the loop.
// ---------------------------------------------------------------------------
export function generateSurfboardGeometry(params) {
  const outline   = generateOutline(params);
  const rockerPts = generateRocker(params);
  const thickPts  = generateThickness(params);

  const L  = params.lengthIn;
  const Lm = inchesToMeters(L);

  const CS_N = 32;
  const RingLen = 2 * CS_N;

  const tailShape = params.tailShape || 'squash';

  // ── Nose extra stations ───────────────────────────────────────────────────
  // Prepend 6 stations that sine-ramp halfWidth to 0, forming a smooth dome.
  // i=0 is outermost tip (x=-0.15"), i=5 is body nose (x=0").
  const baseHwNose  = outline[0].halfWidth;
  const baseRkNose  = rockerPts[0].z;
  const baseThNose  = thickPts[0].thickness;
  const noseOffsets = [0.15, 0.08, 0.03, 0.01, 0.005, 0];
  const noseExtra = noseOffsets.map((d, i) => {
    const sinFrac = Math.sin((Math.PI / 2) * i / (noseOffsets.length - 1));
    return {
      x:         -d,
      halfWidth:  baseHwNose  * sinFrac,
      z:          baseRkNose,
      thickness:  Math.max(0.04, baseThNose * (sinFrac * 0.9 + 0.1)),
    };
  });

  // ── Tail extra stations ───────────────────────────────────────────────────
  // Only add taper stations for shapes that end in a point (pin/round/diamond).
  // Swallow/fish and squash/square are closed explicitly from the last body ring.
  const usesTailRamp = tailShape === 'pin' || tailShape === 'diamond' || tailShape === 'round';
  const baseHwTail  = outline[outline.length - 1].halfWidth;
  const baseRkTail  = rockerPts[rockerPts.length - 1].z;
  const baseThTail  = thickPts[thickPts.length - 1].thickness;
  const tailOffsets = [0.005, 0.01, 0.03, 0.08, 0.15];
  const tailExtra = usesTailRamp ? tailOffsets.map((d, i) => {
    const sinFrac = Math.sin((Math.PI / 2) * (tailOffsets.length - 1 - i) / (tailOffsets.length - 1));
    return {
      x:         L + d,
      halfWidth:  baseHwTail  * sinFrac,
      z:          baseRkTail,
      thickness:  Math.max(0.04, baseThTail * (sinFrac * 0.9 + 0.1)),
    };
  }) : [];

  // ── Build combined station arrays ─────────────────────────────────────────
  const allOutline = [
    ...noseExtra.map(e => ({ x: e.x, halfWidth: e.halfWidth })),
    ...outline,
    ...tailExtra.map(e => ({ x: e.x, halfWidth: e.halfWidth })),
  ];
  const allRocker = [
    ...noseExtra.map(e => ({ x: e.x, z: e.z })),
    ...rockerPts,
    ...tailExtra.map(e => ({ x: e.x, z: e.z })),
  ];
  const allThick = [
    ...noseExtra.map(e => ({ x: e.x, thickness: e.thickness })),
    ...thickPts,
    ...tailExtra.map(e => ({ x: e.x, thickness: e.thickness })),
  ];

  const NS = allOutline.length;

  const positions = [];
  const uvs       = [];
  const indices   = [];

  // ── Build a vertex ring at each station ───────────────────────────────────
  const rings = [];
  for (let i = 0; i < NS; i++) {
    const hwIn = allOutline[i].halfWidth;
    const rY   = inchesToMeters(allRocker[i].z);
    const thM  = inchesToMeters(allThick[i].thickness);
    const hwM  = inchesToMeters(hwIn);
    // x is in inches; offset by half board length to center at origin
    const xM   = inchesToMeters(allOutline[i].x) - Lm / 2;

    const cs = crossSection(hwM, thM, params.railType, params.deckDome, CS_N);

    const ring = [];
    for (let j = 0; j <= CS_N; j++)       // right side, z positive
      ring.push([xM, rY + cs[j].z, cs[j].y]);
    for (let j = CS_N - 1; j >= 1; j--)   // left side mirror
      ring.push([xM, rY + cs[j].z, -cs[j].y]);

    rings.push(ring);
  }

  // ── Swallow tail ring deformation ────────────────────────────────────────
  // Pull center-deck vertices rearward over the last ~12 body rings to form
  // the V-notch gradually. Rail apex vertices are untouched so wings stay wide.
  const bodyEndIdx = noseExtra.length + outline.length - 1;

  if (tailShape === 'swallow' || tailShape === 'fish') {
    const swDepthM = inchesToMeters(params.swallowDepthIn || 2.5);
    // how many center verts per half to pull (near deck center j=CS_N)
    const notchHalfVerts = Math.round(CS_N * 0.20);
    const deformCount = 12; // rings to deform (≈4" from tail at 0.33"/station)

    for (let k = 0; k < deformCount; k++) {
      const ri = bodyEndIdx - k;
      if (ri < noseExtra.length) break; // don't deform into nose region
      const ring = rings[ri];
      // k=0 (tail end) = full pull; k=deformCount-1 (earliest) = zero pull
      const pullFrac = Math.pow((deformCount - 1 - k) / (deformCount - 1), 1.5);
      const pullM = pullFrac * swDepthM;

      for (let p = 0; p <= notchHalfVerts; p++) {
        const blend = 1 - p / (notchHalfVerts + 1);
        const jr = CS_N - p;      // right half deck-center verts
        const jl = CS_N + 1 + p;  // left half deck-center verts
        if (jr >= 0)         ring[jr][0] -= pullM * blend;
        if (jl < ring.length) ring[jl][0] -= pullM * blend;
      }
    }
  }

  // ── Write vertex + UV buffers ─────────────────────────────────────────────
  for (let i = 0; i < NS; i++) {
    for (let j = 0; j < RingLen; j++) {
      positions.push(...rings[i][j]);
      uvs.push(i / (NS - 1), j / (RingLen - 1));
    }
  }

  // ── Hull faces (quad strip, all stations) ─────────────────────────────────
  for (let i = 0; i < NS - 1; i++) {
    for (let j = 0; j < RingLen - 1; j++) {
      const a = i * RingLen + j,        b = a + 1;
      const c = (i + 1) * RingLen + j,  d = c + 1;
      indices.push(a, c, b,  b, c, d);
    }
    // close ring seam (last vertex wraps to first)
    const a = i * RingLen + RingLen - 1, b = i * RingLen;
    const c = (i + 1) * RingLen + RingLen - 1, d = (i + 1) * RingLen;
    indices.push(a, c, b,  b, c, d);
  }

  // ── Nose tip fan ──────────────────────────────────────────────────────────
  // Ring 0 is the innermost nose station (near-zero width). Fan its vertices
  // to a single tip point to close the end.
  const noseTipX = inchesToMeters(allOutline[0].x) - Lm / 2;
  const noseTipY = inchesToMeters(allRocker[0].z);
  const noseTipIdx = positions.length / 3;
  positions.push(noseTipX, noseTipY, 0);
  uvs.push(0, 0.5);

  const nr0 = 0; // base index of ring 0
  for (let j = 0; j < RingLen - 1; j++)
    indices.push(noseTipIdx, nr0 + j + 1, nr0 + j);
  indices.push(noseTipIdx, nr0, nr0 + RingLen - 1);

  // ── Tail closing ─────────────────────────────────────────────────────────
  // Shapes with explicit caps (swallow, squash) close from the last body ring.
  // Tapering shapes (pin, round) close from the last sine-ramp station.
  const bodyTailXM  = inchesToMeters(outline[outline.length - 1].x) - Lm / 2; // = Lm/2
  const bodyTailY   = inchesToMeters(allRocker[bodyEndIdx].z);
  const bodyTailThM = inchesToMeters(allThick[bodyEndIdx].thickness);
  // rail apex Z = board half-width in meters at the last body ring
  const bodyRailZ   = rings[bodyEndIdx][Math.round(CS_N / 2)][2];

  // for pin/round: close from last taper ring; for all others: last body ring
  const lastRingBase = usesTailRamp ? (NS - 1) * RingLen : bodyEndIdx * RingLen;
  const closeTailXM  = usesTailRamp
    ? (inchesToMeters(allOutline[NS - 1].x) - Lm / 2)
    : bodyTailXM;
  const closeTailY   = usesTailRamp
    ? inchesToMeters(allRocker[NS - 1].z)
    : bodyTailY;
  const closeTailThM = usesTailRamp
    ? inchesToMeters(allThick[NS - 1].thickness)
    : bodyTailThM;

  if (tailShape === 'swallow' || tailShape === 'fish') {
    // Close from last body ring. Notch is pulled back by swDepthM from body tail end.
    // Wing tips splay slightly past the body end at full half-width.
    const swDepthM  = inchesToMeters(params.swallowDepthIn || 2.5);
    const wingExtM  = inchesToMeters(0.4); // wings protrude slightly past body end
    const notchIdx  = positions.length / 3;
    positions.push(bodyTailXM - swDepthM, bodyTailY + bodyTailThM * 0.5, 0);
    uvs.push(1, 0.5);
    const rWingIdx  = positions.length / 3;
    positions.push(bodyTailXM + wingExtM, bodyTailY + bodyTailThM * 0.4,  bodyRailZ);
    uvs.push(1, 0.75);
    const lWingIdx  = positions.length / 3;
    positions.push(bodyTailXM + wingExtM, bodyTailY + bodyTailThM * 0.4, -bodyRailZ);
    uvs.push(1, 0.25);

    const innerCut = Math.round(CS_N * 0.25);
    for (let j = 0; j < CS_N - 1; j++) {
      const tip = (j >= innerCut && j < CS_N - innerCut) ? rWingIdx : notchIdx;
      indices.push(lastRingBase + j, tip, lastRingBase + j + 1);
    }
    for (let j = CS_N; j < RingLen - 1; j++) {
      const d = Math.min(j - CS_N, RingLen - 1 - j);
      const tip = d >= innerCut ? lWingIdx : notchIdx;
      indices.push(lastRingBase + j, lastRingBase + j + 1, tip);
    }
    indices.push(lastRingBase + CS_N - 1, rWingIdx,  lastRingBase + CS_N);
    indices.push(lastRingBase + RingLen - 1, lastRingBase, notchIdx);

  } else if (tailShape === 'squash' || tailShape === 'square') {
    // Flat face: project the body-end ring onto a plane 0.2" past the body end.
    const faceExtM = inchesToMeters(0.2);
    const faceX    = bodyTailXM + faceExtM;
    const faceMidY = bodyTailY + bodyTailThM * 0.5;
    const cIdx = positions.length / 3;
    positions.push(faceX, faceMidY,  0);          uvs.push(1, 0.5);
    const rIdx = positions.length / 3;
    positions.push(faceX, faceMidY,  bodyRailZ);  uvs.push(1, 0.75);
    const lIdx = positions.length / 3;
    positions.push(faceX, faceMidY, -bodyRailZ);  uvs.push(1, 0.25);

    const sqCut = Math.round(CS_N * 0.25);
    for (let j = 0; j < CS_N - 1; j++) {
      const tip = (j >= sqCut && j < CS_N - sqCut) ? rIdx : cIdx;
      indices.push(lastRingBase + j, tip, lastRingBase + j + 1);
    }
    for (let j = CS_N; j < RingLen - 1; j++) {
      const d = Math.min(j - CS_N, RingLen - 1 - j);
      const tip = d >= sqCut ? lIdx : cIdx;
      indices.push(lastRingBase + j, lastRingBase + j + 1, tip);
    }
    indices.push(lastRingBase + CS_N - 1, rIdx, lastRingBase + CS_N);
    indices.push(lastRingBase + RingLen - 1, lastRingBase, cIdx);
    indices.push(rIdx, lIdx, cIdx);

  } else {
    // Pin / round / diamond: fan to a single point at the end of the taper.
    const tipY = tailShape === 'round'
      ? closeTailY + closeTailThM * 0.5
      : closeTailY;
    const tailTipIdx = positions.length / 3;
    positions.push(closeTailXM, tipY, 0);
    uvs.push(1, 0.5);

    for (let j = 0; j < RingLen - 1; j++)
      indices.push(tailTipIdx, lastRingBase + j, lastRingBase + j + 1);
    indices.push(tailTipIdx, lastRingBase + RingLen - 1, lastRingBase);
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  geo.setAttribute('uv',       new THREE.Float32BufferAttribute(uvs, 2));
  geo.setIndex(indices);
  geo.computeVertexNormals();
  return geo;
}
